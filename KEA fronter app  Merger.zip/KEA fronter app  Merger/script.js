window.addEventListener("load", sidenVises);
var acc = document.getElementsByClassName("accordion");
var i;


for (i = 0; i < acc.length; i++) {
    acc[i].addEventListener("click", function () {
        /* Toggle between adding and removing the "arotate" class
        to arrows */

        this.lastElementChild.classList.toggle("rotate");


        /* Toggle between hiding and showing the active panel */
        var panel = this.nextElementSibling;
        if (panel.style.display === "block") {
            panel.style.display = "none";
        } else {
            panel.style.display = "block";
        }
    });




}

function sidenVises() {
    console.log("siden vises");
    //Hvad der skal ske
    showStart();

}


/******************

Åbne Nav Menu
*******************/

function showStart() {
    console.log("show start");


    document.querySelector("#burgermenu").addEventListener("click", showNav)

}

function showNav() {
    console.log("showNav")
    document.querySelector("#alex_nav").classList.remove("hide");
    document.querySelector("#alex_nav").classList.add("nav_animationin");
    document.querySelector("#alex_tilbagepil1").addEventListener("click", goingHome)

}


function goingHome() {
    console.log("goingHome")
    document.querySelector("#alex_nav").classList.add("hide");

}



/******************

Åbne nav menu SLUT
*******************/

/******************

Åbne nyhedssider
*******************/





/******************

Åbne nyhedssider SLUT
*******************/
